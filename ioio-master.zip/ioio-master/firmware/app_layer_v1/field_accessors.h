#ifndef __FIELD_ACCESSORS_H__
#define __FIELD_ACCESSORS_H__

void AssignUxRXIF(unsigned index, unsigned value);
void AssignUxRXIE(unsigned index, unsigned value);
void AssignUxRXIP(unsigned index, unsigned value);
void AssignUxTXIF(unsigned index, unsigned value);
void AssignUxTXIE(unsigned index, unsigned value);
void AssignUxTXIP(unsigned index, unsigned value);
void AssignICxIF(unsigned index, unsigned value);
void AssignICxIE(unsigned index, unsigned value);
void AssignICxIP(unsigned index, unsigned value);
void AssignSPIxIF(unsigned index, unsigned value);
void AssignSPIxIE(unsigned index, unsigned value);
void AssignSPIxIP(unsigned index, unsigned value);
void AssignMI2CxIF(unsigned index, unsigned value);
void AssignMI2CxIE(unsigned index, unsigned value);
void AssignMI2CxIP(unsigned index, unsigned value);

#endif  // __FIELD_ACCESSORS_H__
