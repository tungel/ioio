package ioio.tests.torture;


interface Test<E> {
	E run() throws Exception;
}
